package com.example.mykontakt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;

import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private ListView lvZoznam;
    private TextView texter;
    ArrayList<String> contactList;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvZoznam = (ListView) findViewById(R.id.listView);
        texter = (TextView) findViewById(R.id.textview);
        texter.setEnabled(false);
        contactList = new ArrayList<String>();

        Button b = findViewById(R.id.button);
        b.setOnClickListener((view) -> buttonClick(view));

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    1);
        }

        priprava2();
    }

    private void priprava2() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_CONTACTS},
                    2);
        }
    }


    public void buttonClick(View view) {
        Citac c = new Citac();
        c.execute();
    }

    private class Citac extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            getContacts();
            return null;
        }

        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            if (contactList != null && contactList.size() > 0) {
                getSupportActionBar().setSubtitle(contactList.size() + " kontaktov");
                adapter = new ArrayAdapter(MainActivity.this,
                        android.R.layout.simple_list_item_1,
                        contactList);
                lvZoznam.setAdapter(adapter);
                texter.setText(convertContactListToJson(contactList));
            }
            Toast.makeText(MainActivity.this, "done", Toast.LENGTH_SHORT).show();
        }

        private void getContacts() {
            contactList.clear();

            Cursor cursor;
            Uri CONTENT_URI = ContactsContract.Contacts.CONTENT_URI;
            ContentResolver contentResolver = getContentResolver();
            cursor = contentResolver.query(CONTENT_URI, null, null, null, null);

            if (cursor.getCount() > 0) {
                int id_index = cursor.getColumnIndex(ContactsContract.Contacts._ID);
                int id_display_name = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
                int id_hpn = cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER);
                Uri PhoneCONTENT_URI = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
                String Phone_CONTACT_ID = ContactsContract.CommonDataKinds.Phone.CONTACT_ID;
                String NUMBER = ContactsContract.CommonDataKinds.Phone.NUMBER;

                while (cursor.moveToNext()) {
                    String contact_id = cursor.getString(id_index);
                    String name = cursor.getString(id_display_name);
                    String kontakt = name;
                    int hasPhoneNumber = Integer.parseInt(cursor.getString(id_hpn));

                    if (hasPhoneNumber == 1) {
                        Cursor phoneCursor = contentResolver.query(PhoneCONTENT_URI, null,
                                Phone_CONTACT_ID + " = ?", new String[]{contact_id}, null);
                        int id_number = phoneCursor.getColumnIndex(NUMBER);
                        while (phoneCursor.moveToNext()) {
                            kontakt += "\n - " +
                                    phoneCursor.getString(id_number);
                        }
                        phoneCursor.close();
                    }
                    contactList.add(kontakt);
                }
            }
            cursor.close();
        }

    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Kontakty - OK", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Kontakty nebudu", Toast.LENGTH_SHORT).show();
                }
            case 2:
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Kontakty zapis - OK", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Kontakty zapis nebudu", Toast.LENGTH_SHORT).show();
                }
        }
    }

    private void pridajKontakt(String meno, String telefon) {
        String DisplayName = meno;
        String MobNr = telefon;

        ArrayList<ContentProviderOperation> ops = new ArrayList<ContentProviderOperation>();
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build());

        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE,
                        ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                        DisplayName)
                .build());

        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE,
                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, MobNr)
                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE,
                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                .build());

        try {
            getContentResolver().applyBatch(ContactsContract.AUTHORITY, ops);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), e.getMessage(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    private String convertContactListToJson(ArrayList<String> contactList) {
        JSONArray jsonArray = new JSONArray();

        for (String contact : contactList) {
            JSONObject contactJson = new JSONObject();
            String[] lines = contact.split("\n");

            try {
                contactJson.put("name", lines[0].trim());

                if (lines.length > 1) {
                    String firstPhoneNumber = lines[1].replaceFirst(" - ", "");
                    contactJson.put("phone", firstPhoneNumber);
                } else {
                    contactJson.put("phone", "");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            jsonArray.put(contactJson);
        }
        return jsonArray.toString();
    }

    public void doPush(View v) {
        sendData();
    }

    public void doUpdate(View v) {
        final String url = "http://10.0.2.2/scriptsKontakt/vypis.php";
        RemoteCom rcom = new RemoteCom();

        rcom.execute(url, "1");
    }

    public void sendData() {
        final String url = "http://10.0.2.2/scriptsKontakt/zapis.php";

        RemoteCom rcom = new RemoteCom();
        rcom.execute(url, "2", convertContactListToJson(contactList));
    }

    public class RemoteCom extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String stringUrl = params[0];
            int operation = Integer.parseInt(params[1]);
            String result = "", line;

            try {
                URL url = new URL(stringUrl);
                URLConnection conn = url.openConnection();

                conn.setDoOutput(true);
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);

                switch (operation) {
                    case 1:
                        conn.connect();
                        break;
                    case 2: {
                        String json = params[2];

                        OutputStream output = conn.getOutputStream();
                        String data = URLEncoder.encode("json", "UTF-8") + "=" + URLEncoder.encode(json, "UTF-8");

                        output.write(data.getBytes(StandardCharsets.UTF_8));
                        output.flush();
                        output.close();
                        break;
                    }
                }

                InputStreamReader streamReader = new InputStreamReader(conn.getInputStream());
                BufferedReader reader = new BufferedReader(streamReader);

                while ((line = reader.readLine()) != null) {
                    result += line + "\n";
                }

                reader.close();
                streamReader.close();
            } catch (Exception e) {
                Log.d("x", e.toString());
                result = null;
            }

            return result;
        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            TextView tv = findViewById(R.id.textview);

            if (result == null) {
                tv.setText("Error");
            } else {
                tv.setText(result);
                String[] data = result.split("\\|");
                for (int i = 0; i < data.length; i++) {
                    if (!data[i].isEmpty()) {
                        String[] parts = data[i].split("; ");
                        if (parts.length == 3) {
                            String name = parts[1].trim();
                            String phone = parts[2].trim();
                            System.out.print(name + " | " + phone);
                            pridajKontakt(name, phone);
                        }
                    }
                }

                Toast.makeText(MainActivity.this, "Done", Toast.LENGTH_SHORT).show();
            }
        }

    }
}