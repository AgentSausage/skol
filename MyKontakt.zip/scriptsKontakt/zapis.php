<?php
  include 'config.php';

  // vytvorenie spojenia
  $conn = mysqli_connect($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
   }
  
  // prečítanie údajov získaných cez post
  $json = $_POST["json"];
  $data = json_decode($json, true);

  if (!empty($data) && is_array($data)) {
    $stmt = $conn->prepare("INSERT INTO kontakt (name, phone) VALUES (?, ?)");

    if ($stmt) {
        foreach ($data as $contact) {
            $name = $contact['name'];
            $phone = $contact['phone'];

            $stmt->bind_param("ss", $name, $phone);

            $stmt->execute();
        }

        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
  } else {
    echo "No valid data received.";
  }

  // // dotaz na databázu
  // $sql= "INSERT INTO kontakt (name, phone) VALUES ('$name', '$phone')";
  // // vypis, ci zapis prebehol ok alebo nie
  // if (mysqli_query($conn,$sql)) { echo "OK ".$sql;
  //  } else { echo "0".$sql; }
  // mysqli_close($conn); // zatvorenie spojenia
  $conn->close();
?>
