<?php
  include 'config.php';

 // pokus o pripojenie
 $conn = mysqli_connect($servername, $username, $password,  $dbname);
 if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }
 // výber údajov
 $sql = "SELECT id, name, phone FROM kontakt";
 $result = mysqli_query($conn, $sql);

 if(mysqli_num_rows($result) == 0) {echo "0"; }  // ak je prázdno
	else {
    // výstup po záznamoch oddelených znakom „|“
    while($row = mysqli_fetch_assoc($result)) {
        echo $row["id"]. "; " . $row["name"]. "; " . $row["phone"]. " | ";
    }
 }
 mysqli_close($conn);
?>  
